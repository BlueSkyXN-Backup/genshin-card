#!/bin/bash

export COOKIE="account_id=76XXXXXX; cookie_token=vME1l1KHa2f4XXXXXXXXXXXXXXXXXXXkwKUS9A; ltoken=sVSiXmFStGPjfppJRS4oXXXXXXXXXXXXXVajoJk8; ltuid=76XXXXXXXX" && yarn serve